//
//  EspressoSyntaxCore.h
//  Espresso
//

@interface SXTypeIdentifier : NSObject

// Designated initializer
- (id)initWithString:(NSString *)string;
+ (id)typeIdentifierWithString:(NSString *)string;

// Checking for equality
- (BOOL)isEqualToTypeIdentifier:(SXTypeIdentifier *)anIdentifier;

// String representation of the identifier
- (NSString *)stringValue;

@end


@interface SXSelectable : NSObject

// An identifier that represents the selectable's type
@property(readonly) SXTypeIdentifier *typeIdentifier;

@end


@interface SXZone : SXSelectable <NSFastEnumeration>

@property(readonly) NSRange range;
@property(readonly) NSString *text;

// Syntax tree structure (to iterate, use fast enumeration)
- (id)parent;
- (NSUInteger)childCount;
- (id)childAtIndex:(NSUInteger)index;

@end


@interface SXZoneRange : NSObject

@property(readonly) SXZone *startZone;
@property(readonly) SXZone *endZone;

@end


@interface SXZoneTree : NSObject

// Root syntax zone
@property(readonly) SXZone *rootZone;

// Return the deepest zone at the given index
- (SXZone *)zoneAtCharacterIndex:(NSUInteger)location;

// Return the top-level zones that are completely contained in the given range.
// Note: the returned zones may not share the same parent! Some zones might be
// deeper than others, since this method tries to find *all* zones inside range.
- (NSArray *)zonesInCharacterRange:(NSRange)range;

@end


@interface SXSelector : NSObject

// Initializers
+ (NSArray *)selectorsFromString:(NSString *)selectorString;
+ (SXSelector *)selectorWithString:(NSString *)selectorString;

// Matching the selector
- (BOOL)matches:(SXSelectable *)node;
- (BOOL)matches:(SXSelectable *)node captureIntoDictionary:(NSMutableDictionary *)captureDictionary;

@end


// JavaScript: SXSelectorGroup is bridged as SXSelector, no JS equivalent for objective-C SXSelector
@interface SXSelectorGroup : NSObject <NSFastEnumeration>

// Initializers
- (id)initWithString:(NSString *)string;
+ (SXSelectorGroup *)selectorGroupWithString:(NSString *)string;

// A selector group matches a selectable if any of the selectors match it
- (BOOL)matches:(SXSelectable *)node;
- (BOOL)matches:(SXSelectable *)node captureIntoDictionary:(NSMutableDictionary *)captureDictionary;

@end


@interface SXSelectable (SXQueryAdditions)

// Filters selectables from the zone's children, and searches recursively until maximumDepth is reached.
// To search for children only, specify maximumDepth:1
- (NSArray *)descendantSelectablesMatchingSelectors:(SXSelectorGroup *)selectors;
- (NSArray *)descendantSelectablesMatchingSelectors:(SXSelectorGroup *)selectors maximumDepth:(NSUInteger)maximumDepth;

@end


@interface NSArray (SXQueryAdditions)

// Filters selectables from the array, and searches recursively until maximumDepth is reached.
// To search for children only, specify maximumDepth:1
- (NSArray *)selectablesMatchingSelectors:(SXSelectorGroup *)selectors;
- (NSArray *)selectablesMatchingSelectors:(SXSelectorGroup *)selectors maximumDepth:(NSUInteger)maximumDepth;

@end
