//
//  EspressoTextActions.h
//  Espresso
//

// All actions share the same generic interface; the specific context changes
#import "EspressoActions.h"
#import "EspressoTextCore.h"
#import "EspressoSyntaxCore.h"
#import "EspressoItemizerCore.h"
#import "EspressoDocumentActions.h"


//
// Text actions (defined under TextActions in sugars) get a context conforming to this interface.
//
@interface NSObject (TextActionContext)

@property(nonatomic,readonly) NSString *string;
@property(nonatomic,readonly) id lineStorage;

// JavaScript: applyTextRecipe(recipe, options) or applyTextRecipe(recipe)
- (BOOL)applyTextRecipe:(CETextRecipe *)textRecipe options:(CETextOptions)options;
- (BOOL)applyTextRecipe:(CETextRecipe *)textRecipe; // Convenience with options:CETextConvertingVerbatim

// JavaScript: insertTextSnippet(recipe, options) or insertTextSnippet(recipe)
- (BOOL)insertTextSnippet:(CETextSnippet *)textSnippet options:(CETextOptions)options;
- (BOOL)insertTextSnippet:(CETextSnippet *)textSnippet; // Convenience with options:CETextConvertingDefault

// Inserting Navigator items
- (BOOL)insertItemUsingTextSnippet:(CETextSnippet *)textSnippet options:(CEInsertItemOptions)options;

// Selecting text
// Note that there is no selectedRange utility method; this is mostly to ensure that actions
// at least consider the possibility of discontiguous selections.
@property(nonatomic,copy) NSArray *selectedRanges;

// Text preferences
@property(nonatomic,readonly) id <CETextPreferences> textPreferences;

// Syntax zone metadata
@property(nonatomic,readonly) SXZoneTree *syntaxTree;

// Itemizer metadata
@property(nonatomic,readonly) CEItemizer *itemizer;

// Context sensitive settings; return type can vary from setting to setting and must be checked.
- (id)settingForKey:(NSString *)key inRange:(NSRange)range;

// Returns a window suitable for displaying a sheet. May be nil.
@property(nonatomic,readonly) NSWindow *windowForSheet;

// Document context (see EspressoDocumentActions.h)
@property(nonatomic,readonly) id documentContext;

@end
