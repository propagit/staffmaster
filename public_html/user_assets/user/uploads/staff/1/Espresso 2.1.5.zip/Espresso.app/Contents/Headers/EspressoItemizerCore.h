//
//  EspressoItemizerCore.h
//  Espresso
//

#import <Cocoa/Cocoa.h>
#import "EspressoSyntaxCore.h"


@protocol CEItemizedText

// Returns nil if the range is invalid
- (NSString *)substringWithRange:(NSRange)range;

@end


//
// Core item class
//
@interface CEItem : SXSelectable
{
	@private
	id _auxiliaryStorage;
}

@property(readonly) SXTypeIdentifier *typeIdentifier;
@property(readonly) NSRange range;
@property(readonly) NSRange innerRange;

@property(readonly) id parentItem;
@property(readonly) NSArray *childItems;

// Access to syntax level information (guaranteed to be currently valid)
@property(readonly) SXZoneRange *syntaxRange;

// Access to source text
@property(readonly) id <CEItemizedText> itemizedText;

// Return the inner string of a zone, which can be used to get the text between quotes of a string. (also useful for comments, ...)
// Detects punctuation.definition.begin and punctuation.definition.end to do its thing.
- (NSString *)innerTextForSyntaxZone:(SXZone *)zone;

@end


//
// Itemizer class; you get access to this in text action contexts
//
@interface CEItemizer : NSObject

// Root items
@property(readonly) NSArray *items;

// Return the deepest item at the given index
- (id)itemAtCharacterIndex:(NSUInteger)location;

// Return the top-level items that are completely contained in the given range.
// Note: the returned items may not share the same parent! Some items might be
// deeper than others, since this method tries to find every top-level item.
- (NSArray *)itemsInCharacterRange:(NSRange)range;

// Return the smallest (deepest) item that fully encloses the given range.
// May be nil if no such item was found.
- (id)smallestItemContainingCharacterRange:(NSRange)range;

@end


//
// Navigator items can be inserted with the following options (see EspressoTextActions.h)
//
enum : NSUInteger {
	
	// When the application deems this behavior appropriate, embeds the current item selection in the text snippet by using the $0 placeholder.
	// Use this option for items that can contain other items, like groups or tags. There is no guarantee any wrapping will occur when this
	// option is enabled, it simply hints that wrapping would be desirable.
	CEInsertItemByWrappingSelection = (1UL << 0)
};
typedef NSUInteger CEInsertItemOptions;
