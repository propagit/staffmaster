//
//  EspressoDocumentActions.h
//  Espresso
//

// All actions share the same generic interface; the specific context changes
#import "EspressoActions.h"


//
// Document contexts differ from file contexts in that they are focused on an actual user document
// instead of the pure file representation. Document contexts currently don't have dedicated actions,
// but text actions do reference a document context to work with.
//
@interface NSObject (DocumentActionContext)

// File URL. May be nil for unsaved documents.
@property(readonly) NSURL *fileURL;

@end
