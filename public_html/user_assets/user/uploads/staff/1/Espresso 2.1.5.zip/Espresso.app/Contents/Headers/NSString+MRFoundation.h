//
//  NSString+MRFoundation.h
//  MRFoundation
//
//  Copyright (c) 2003-2013 MacRabbit. All rights reserved.
//


@interface NSString (MRFoundation)

#define MRIsWhitespace(char) (char == ' ' || char == '\n' || char == '\t' || char == '\r')
#define MRIsEmptyString(string) (string == nil || [string length] == 0)

+ (NSString *)stringWithNewUUID;

- (NSString *)stringByCapitalizingFirstLetter;

- (NSString *)stringByTrimmingWhitespaceAndNewlines;
- (NSString *)stringByRemovingLeadingWhitespace;
- (NSString *)stringByRemovingTrailingWhitespace;

- (BOOL)containsString:(NSString *)str;
- (BOOL)containsString:(NSString *)string options:(NSStringCompareOptions)options;
- (BOOL)containsAnyOfStrings:(id <NSFastEnumeration>)strings options:(NSStringCompareOptions)options;

- (BOOL)isEqualToAnyOfStrings:(id <NSFastEnumeration>)strings;
- (BOOL)hasAnyOfSuffixes:(id <NSFastEnumeration>)suffixes;
- (BOOL)hasAnyOfPrefixes:(id <NSFastEnumeration>)prefixes;

// Returns a relative path conforming to standard URL path resolving rules, so suffix directories with / if needed.
- (NSString *)relativePathWithBasePath:(NSString *)basePath;

@end


@interface NSMutableString (MRFoundation)

- (void)trimWhitespaceAndNewlines;
- (NSUInteger)replaceOccurrencesOfString:(NSString *)target withString:(NSString *)replacement;

@end
