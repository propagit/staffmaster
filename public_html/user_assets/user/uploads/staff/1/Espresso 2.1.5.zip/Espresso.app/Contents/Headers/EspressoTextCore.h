//
//  EspressoTextCore.h
//  Espresso
//


//
// Some Text APIs can be used with the following conversion options (see EspressoTextActions.h)
//
enum : NSUInteger {
	
	// Use default options for the relevant context. The concrete options activated by this value are considered "best" for the intended purpose.
	CETextOptionsDefault										= (1UL << 15),
	
	
	// Use the text as-is, without making any changes
	CETextOptionVerbatim										= 0,
	
	// Add/remove indentation as necessary to visually align inserted text as it was before, but at the
	// indentation level of the text it was inserted into.
	CETextOptionNormalizeIndentationLevel						= (1UL << 0),
	
	// Convert newline characters to the default/user settings.
	CETextOptionNormalizeLineEndingCharacters					= (1UL << 1),
	
	// Convert indentation characters to the default/user settings.
	CETextOptionNormalizeIndentationCharacters					= (1UL << 2)
};
typedef NSUInteger CETextOptions;
typedef NSInteger CETextConvertingOptions DEPRECATED_ATTRIBUTE;

// Deprecated naming
#define CETextConvertingVerbatim CETextOptionVerbatim,
#define CETextConvertingNormalizeIndentationLevel CETextOptionNormalizeIndentationLevel,
#define CETextConvertingNormalizeLineEndingCharacters CETextOptionNormalizeLineEndingCharacters,
#define CETextConvertingNormalizeIndentationCharacters CETextOptionNormalizeIndentationCharacters,


//
// Instead of directly manipulating text objects, you work with text recipes. These objects record
// the changes you want to make, and then get applied as a whole. The main advantage of a recipe approach
// is that you don't need to take range shifting into account when replacing multiple ranges. It doesn't 
// matter in what order you define the changes; the recipe takes care of the range shifting logic.
//
@interface CETextRecipe : NSObject

- (id)init;
+ (CETextRecipe *)textRecipe;

// Applied recipes group changes by default, for performance reasons. Set to NO to perform each change individually.
@property BOOL coalescesChanges;

// Calling these methods do not cause any changes to the text, they merely build up the recipe.
// Important: it's not allowed to pass any overlapping ranges -- this will raise an exception.
- (void)replaceRange:(NSRange)aRange withString:(NSString *)aString;
- (void)insertString:(NSString *)aString atIndex:(NSUInteger)anIndex;
- (void)deleteRange:(NSRange)aRange;

// Deprecated API for building recipes.
- (void)addReplacementString:(NSString *)string forRange:(NSRange)range DEPRECATED_ATTRIBUTE;
- (void)addInsertedString:(NSString *)string forIndex:(NSUInteger)location DEPRECATED_ATTRIBUTE;
- (void)addDeletedRange:(NSRange)range DEPRECATED_ATTRIBUTE;

// Calling -prepare on a recipe blocks any future changes to it.
- (void)prepare;

// Access to the changes in this recipe. Requires allocated buffers with enough space.
// Important: these methods will raise an exception if the recipe hasn't been prepared!
- (NSUInteger)numberOfChanges;
- (void)getReplacedRanges:(NSRange **)ranges replacementLengths:(NSUInteger **)lengths;

// Undo UI hook
@property(retain) NSString *undoActionName;

@end


//
// Text snippets are pieces of text that can contain smart areas that mirror others,
// and that can be navigated by tabbing between the different fields. The initializers
// take a snippet format string. Use text snippets in combination with a text action context.
//
@interface CETextSnippet : NSObject

// JavaScript: new CETextSnippet("your snippet")
- (id)initWithString:(NSString *)string;
+ (id)snippetWithString:(NSString *)string;

@end


//
// Line storages track line ranges by storing the line start for each line.
// You can make use of this by calling the NSIndexSet accessors, or by using
// the dedicated line number methods.
///
@protocol CELineStorage

// Get the number of lines.
- (NSUInteger)numberOfLines;

// Get the beginning of the line at a given character index, and optionally return the line number by reference.
- (NSUInteger)lineStartIndexForIndex:(NSUInteger)characterIndex lineNumber:(NSUInteger *)lineNumber;

// Get the beginning of the line before/after a given character index. Returns NSNotFound if no more line starts were found.
- (NSUInteger)lineStartIndexLessThanIndex:(NSUInteger)characterIndex;
- (NSUInteger)lineStartIndexGreaterThanIndex:(NSUInteger)characterIndex;

// Get the line number of the line at a given character index.
- (NSUInteger)lineNumberForIndex:(NSUInteger)characterIndex;

// Get the line range of the line at a given character index.
- (NSRange)lineRangeForIndex:(NSUInteger)characterIndex;

// Get the line range of a given line number.
- (NSRange)lineRangeForLineNumber:(NSUInteger)lineNumber;

// Get the line range of an arbitrary range, including the line terminators.
- (NSRange)lineRangeForRange:(NSRange)range;

@end


//
// Text preferences hold information about tabs, line endings, ...
//
@protocol CETextPreferences

typedef enum : NSUInteger {
	
	CELineEndingLF		= 0,
	CELineEndingCR		= 1,
	CELineEndingCRLF	= 2,
	
} CELineEndingType;

@property(nonatomic) BOOL insertsSpacesForTab;
@property(nonatomic) NSUInteger numberOfSpacesForTab;
@property(nonatomic,readonly) NSString *tabString;

@property(nonatomic) CELineEndingType lineEndingType;
@property(nonatomic,readonly) NSString *lineEndingString;

@end
