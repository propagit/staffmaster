//
//  MRRangeSet.h
//  MRFoundation
//

#import <Foundation/Foundation.h>


#ifdef EXPORTED_CLASS
EXPORTED_CLASS
#endif

@interface MRRangeSet : NSObject
{
	@private
	NSUInteger count;
	NSUInteger capacity;
	NSRange *ranges;
	BOOL allowsZeroLengthRanges;
}

+ (MRRangeSet *)rangeSet;
- (id)init; // Designated initializer
- (id)initWithRangeValues:(NSArray *)ranges;

@property BOOL allowsZeroLengthRanges; // Defaults to NO

- (void)minusRange:(NSRange)range;
- (void)unionRange:(NSRange)range;
- (void)removeAllRanges;

- (void)shiftRangesStartingAtIndex:(NSUInteger)index by:(NSInteger)delta;

- (void)minusRanges:(NSArray *)ranges;
- (void)unionRanges:(NSArray *)ranges;

- (BOOL)isEmpty;
- (BOOL)intersectsRange:(NSRange)range;

- (NSArray *)ranges;// TODO: DEPRECATED_ATTRIBUTE;
- (NSArray *)rangeValues;
- (void)getRanges:(NSRange **)pointer count:(NSUInteger *)count; // Never free or change the buffer, it is owned by the set

@end
