/*
Sorts selected lines ascending or descending

action.setup:
	- direction (string): 'asc', 'desc', 'random'
	- removeDuplicates (string): 'true' or 'false'; no default
*/

var utils = loadLibrary('tea-utils');

// Trimming regex
var trimRegex = /^\s+|\s+$/g

// Sorting functions
function alphaAsc(a, b) {
	// Trim the strings, because we don't care about whitespace when sorting
	a = a.replace(trimRegex, '');
	b = b.replace(trimRegex, '');
	// Grab our lowercase versions
	var aLower = a.toLocaleLowerCase();
	var bLower = b.toLocaleLowerCase();
	var result = aLower.localeCompare(bLower);
	if (result === 0) {
		// This is the reverse of what you would expect because Javascript alphabetizes uppercase letters prior to lowercase (and we want the opposite)
		result = b.localeCompare(a);
	}
	return result;
}

function alphaDesc(a, b) {
	// Trim the strings, because we don't care about whitespace when sorting
	a = a.replace(trimRegex, '');
	b = b.replace(trimRegex, '');
	// Grab our lowercase versions
	var aLower = a.toLocaleLowerCase();
	var bLower = b.toLocaleLowerCase();
	var result = bLower.localeCompare(aLower);
	if (result === 0) {
		// This is the reverse of what you would expect because Javascript alphabetizes uppercase letters prior to lowercase (and we want the opposite)
		result = a.localeCompare(b);
	}
	return result;
}

action.performWithContext = function(context, outError) {
	// Check if there's a selection, otherwise use all lines
	var ranges = context.selectedRanges;
	if (ranges.length === 1 && ranges[0].length === 0) {
		ranges = [new Range(0, context.string.length)];
	}
	// Setup our recipe
	var recipe = new CETextRecipe();
	
	// Init variabes used in loop
	var text, range, lines, numLines, j, line, result;
	// Loop over the ranges and process them
	var count = ranges.length;
	for (var i = 0; i < count; i++) {
		range = context.lineStorage.lineRangeForRange(ranges[i]);
		text = context.substringWithRange(range);
		
		// If the range is blank, skip this range
		if (text === '') {
			continue;
		}
		
		// Split the text into lines, discarding the linebreaks and trimming empty lines down
		lines = text.split(/[ \t]*[\n\r]+/);
		
		// Loop over the array and clean it up
		numLines = lines.length;
		result = [];
		var removeDuplicates = (typeof action.setup.removeDuplicates !== 'undefined' ? action.setup.removeDuplicates === 'true' : false);
		for (j = 0; j < numLines; j++) {
			line = lines[j];
			// Do not store the line if it is empty or a duplicate (assuming we're filtering duplicates)
			if (line === '' || removeDuplicates && result.indexOf(line) >= 0) {
				continue;
			}
			result.push(line);
		}
		lines = result;
		
		// Sort the lines ascending or descending
		var direction = null;
		if (action.setup.direction) {
			direction = action.setup.direction.toLowerCase();
		}
		if (direction === 'asc') {
			lines.sort(alphaAsc);
		}
		if (direction === 'desc') {
			lines.sort(alphaDesc);
		}
		
		// Shuffle the lines if necessary
		if (direction === 'random') {
			// Fisher-Yates shuffle thanks to Christoph:
			// http://stackoverflow.com/questions/962802/is-it-correct-to-use-javascript-array-sort-method-for-shuffling/962890#962890
			var tmp, current, top = lines.length;
		
			if (top) {
				while(--top) {
					current = Math.floor(Math.random() * (top + 1));
					tmp = lines[current];
					lines[current] = lines[top];
					lines[top] = tmp;
				}
			}
		}
		
		// Join the lines into a single string again
		var linebreak = context.textPreferences.lineEndingString;
		var sortedText = lines.join(linebreak);
		// Add final linebreak if original ends with a linebreak
		if (text.match(/^[\s\S]*?(?:\r\n|\r|\n)$/)) {
			sortedText += linebreak;
		}
		// Insert the text
		recipe.replaceRange(range, sortedText);
	}
	
	// Add an undo name if there is one
	if (action.setup.undoName) {
		recipe.undoActionName = action.setup.undoName;
	}
	
	// Return false if nothing was selected or changed
	recipe.prepare;
	if (recipe.numberOfChanges === 0) {
		return false;
	}
	// Apply the recipe
	return context.applyTextRecipe(recipe);
};