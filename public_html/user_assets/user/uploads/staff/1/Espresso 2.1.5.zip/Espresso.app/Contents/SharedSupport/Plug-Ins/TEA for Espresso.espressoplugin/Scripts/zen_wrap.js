var zen = loadLibrary('zen');

action.performWithContext = function(context, outErrorWhichIsActuallyDictionaryForTEAWrapWithAbbreviationOnlySoDontUseItElsewhere) {
	zen.engine.runAction('wrap_with_abbreviation', new zen.ZenEditor(context), outErrorWhichIsActuallyDictionaryForTEAWrapWithAbbreviationOnlySoDontUseItElsewhere.abbreviation);
	return true;
}
