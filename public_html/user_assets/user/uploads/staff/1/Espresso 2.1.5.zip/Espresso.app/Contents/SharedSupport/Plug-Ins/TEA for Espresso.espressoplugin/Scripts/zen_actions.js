var zen = loadLibrary('zen'),
	cssSelector = new SXSelector('property-list.block.css, property-list.block.css *');

action.performWithContext = function(context, outError) {
	var zone = context.syntaxTree.zoneAtCharacterIndex(context.selectedRanges[0].location);
	// If we are in a CSS zone, delete the selected range (because it likely is CodeSense filling in, and will screw up our abbreviation)
	if (action.setup.action === 'expand_abbreviation' && cssSelector.matches(zone) && context.selectedRanges[0].length > 0) {
		var recipe = new CETextRecipe();
		recipe.deleteRange(context.selectedRanges[0]);
		context.applyTextRecipe(recipe);
	}
	var response = zen.engine.runAction(action.setup.action, new zen.ZenEditor(context));
	return response;
}